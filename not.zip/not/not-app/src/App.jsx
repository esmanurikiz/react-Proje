import React, { useState } from "react";
import Draggable from "react-draggable";
import "./App.css";

function App() {
  const [notes, setNotes] = useState([]);
  const [noteText, setNoteText] = useState("");
  const [noteImage, setNoteImage] = useState(null);

  // Daha fazla pastel renk ekledim
  const colors = [
    "#FAD1D1",
    "#A7C7E7",
    "#A8D8B9",
    "#F7F1B1",
    "#D6AEDD",
    "#F2D0A4",
    "#E2C8F3",
    "#F7C6A3",
    "#C3E6C7",
    "#F8B3B3",
    "#A1D8D2",
    "#D3D3D3",
    "#F9E1F2",
    "#B3D9C6",
    "#F8D1A1",
    "#A9E4D9",
  ];

  const addNote = () => {
    if (noteText.trim() !== "" || noteImage) {
      const newNote = {
        id: Date.now(),
        text: noteText,
        image: noteImage,
        x: 100,
        y: 100,
        isOpen: false,
        color: colors[notes.length % colors.length],
        number: notes.length + 1,
      };
      setNotes([...notes, newNote]);
      setNoteText("");
      setNoteImage(null);
    }
  };

  const handleDrag = (e, data, id) => {
    setNotes((prevNotes) =>
      prevNotes.map((note) =>
        note.id === id ? { ...note, x: data.x, y: data.y } : note
      )
    );
  };

  const deleteNote = (id) => {
    setNotes((prevNotes) => prevNotes.filter((note) => note.id !== id));
  };

  const toggleNote = (id) => {
    setNotes((prevNotes) =>
      prevNotes.map((note) =>
        note.id === id ? { ...note, isOpen: !note.isOpen } : note
      )
    );
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setNoteImage(reader.result);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="App">
      <div className="note-input">
        <textarea
          value={noteText}
          onChange={(e) => setNoteText(e.target.value)}
          placeholder="Notunuzu yazın..."
        ></textarea>
        <input type="file" accept="image/*" onChange={handleImageChange} />
        <button onClick={addNote}>Not Ekle</button>
      </div>
      <div className="notes-container">
        {notes.map((note) => (
          <Draggable
            key={note.id}
            position={{ x: note.x, y: note.y }}
            onDrag={(e, data) => handleDrag(e, data, note.id)}
            scale={1}
          >
            <div
              className={`note ${note.isOpen ? "open" : "closed"}`}
              onClick={() => toggleNote(note.id)}
              style={{ backgroundColor: note.color }}
            >
              {note.isOpen ? (
                <>
                  <div className="note-header">
                    <button
                      className="delete-button"
                      onClick={() => deleteNote(note.id)}
                    >
                      ×
                    </button>
                  </div>
                  <div className="note-body">
                    <strong>Not {note.number}:</strong> {note.text}
                    {note.image && (
                      <img src={note.image} alt="Note" className="note-image" />
                    )}
                  </div>
                </>
              ) : (
                <div>{note.number}</div>
              )}
            </div>
          </Draggable>
        ))}
      </div>
    </div>
  );
}

export default App;
